# Blynk NodeMCU Sensor Monitoring 
Monitoring Temperature Sensor Data in Blynk Dashboard and Mobile App using NodeMCU ESP8266

![alt text](https://github.com/binaryupdates/ThingSpeak-NodeMCU-ESP8266/blob/main/LM35%20Temperature%20Sensor%20NodeMCU%20ESP8266.jpg)
